# WealthLab

**Multi-Asset Portfolio Analytics & Client Wealth Planning**

A complete Google Colab and Python research project for private banking,
wealth management, and portfolio analytics. It combines self-financing portfolio
accounting, performance attribution, risk diagnostics, and an illustrative client
spending plan in an offline HTML report.

![Synthetic portfolio dashboard](docs/images/portfolio_overview.png)

> The shipped example is prominently labeled **synthetic**. It is not historical
> ETF performance. Select Yahoo mode to retrieve market observations yourself.
> This is a tested research prototype, not a production advisory platform.

## Start in Colab

1. Open [Google Colab](https://colab.research.google.com/).
2. Choose **File → Upload notebook** and select `WealthLab_Colab.ipynb`.
3. Choose **Runtime → Run all**. The notebook contains every Python module and
   recreates its own working project; uploading the ZIP is unnecessary.
4. Leave `SOURCE = "demo"` for the offline example, or choose `"yahoo"` in the
   configuration cell and rerun from that cell.
5. Download `client_report.html` and the generated run bundle in the export cell.

The notebook installs core dependencies only if missing. Yahoo mode also checks
for its optional adapter. FRED requires your own `FRED_API_KEY`, preferably entered
through Colab Secrets. Core demo execution needs no API key and no paid data.

## Start locally

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m wealthlab --source demo --root .
```

Windows activation: `.venv\Scripts\activate`.

For live research:

```bash
python -m pip install -r requirements-live.txt
python -m wealthlab --source yahoo --start 2015-01-01 --end 2026-01-01 --root .
```

The end date is exclusive. Default historical dates are fixed for reproducibility,
not automatically extended to today. Use `--refresh` to intentionally replace an
existing matching cache snapshot. Keep an old snapshot separately if needed.

## What is built

- Eight USD-listed ETF proxies, a default 60/40 benchmark, and fixed strategic weights.
- Drifting holdings with monthly, quarterly, or buy-and-hold schedules.
- Self-financing transaction costs, calendar-day advisory fees, and exact dollar P&L attribution.
- CAGR, Sharpe, Sortino, drawdown, historical VaR/ES, beta, and tracking error.
- Trailing Euler risk contributions and hypothetical portfolio stresses.
- Monthly client cash-flow simulation with inflation, one-off spending, and a real legacy target.
- Five professional figure panels, eleven analytical CSV tables, strict JSON provenance,
  and a standalone HTML report with all images embedded.
- Offline tests, a GitHub Actions workflow, and an executable self-contained Colab notebook.

## Architecture

```mermaid
flowchart TD
    A[Validated research and client assumptions] --> B[Explicit data source and checksummed cache]
    B --> C[Strict price validation and returns]
    C --> D[Self-financing portfolio and benchmark]
    D --> E[Performance, attribution, and risk]
    A --> F[Client cash-flow simulation]
    E --> G[Charts, HTML report, CSVs, and provenance]
    F --> G
```

## Repository map

| Path | Purpose |
|---|---|
| `WealthLab_Colab.ipynb` | Complete standalone notebook, including all module source |
| `wealthlab/config.py` | Validated research and client assumptions |
| `wealthlab/data.py` | Synthetic generator, Yahoo/FRED adapters, caching, quality checks |
| `wealthlab/portfolio.py` | Holdings, rebalancing, transaction costs, and fees |
| `wealthlab/analytics.py` | Performance, risk, attribution, monthly returns, stress |
| `wealthlab/planning.py` | Monthly wealth simulations and sensitivity |
| `wealthlab/charts.py` | Five matplotlib figure panels |
| `wealthlab/report.py` | Embedded HTML report and safe JSON serialization |
| `wealthlab/pipeline.py` | Reproducible workflow and exports |
| `wealthlab/__main__.py` | Command-line interface |
| `tests/` | Offline accounting, data-contract, and planning tests |
| `tools/` | Notebook generation and execution checks |
| `config/demo.json` | Editable example mandate |
| `docs/PROJECT_GUIDE.md` | Full build guide, equations, use cases, resume wording, upgrades |
| `docs/VALIDATION.md` | Validation scope and limitations |
| `examples/demo/` | Executed synthetic example report, figures, and tables |
| `data/cache/` | Local data snapshots; ignored by Git |
| `reports/{source}/{run_id}/` | Generated research outputs; ignored by Git |

## Default assumptions

| Assumption | Default |
|---|---|
| Research starting capital | USD 1,000,000 |
| Target weights | SPY 28%, VEA 12%, VWO 8%, AGG 25%, TIP 10%, GLD 7%, VNQ 5%, BIL 5% |
| Benchmark | SPY 60%, AGG 40%; same cost and fee conventions |
| Rebalance | First available close in a new calendar month |
| Trading cost | 5 bps of gross traded notional, including initial deployment |
| Advisory fee | 0.50% annual compounded reduction, accrued by elapsed calendar days |
| Risk-free assumption | 2.50% effective annual; optional lagged FRED DGS3MO proxy |
| Client planning wealth | USD 2,000,000; distinct from backtest capital |
| Annual spending | USD 72,000 in today's purchasing power |
| Additional goal | USD 250,000 in today's dollars at simulation month 24 |
| Planning horizon / legacy goal | 20 years / USD 500,000 in today's dollars |
| Planning return / volatility / inflation | 6% expected annual nominal simple return / 12% / 2.5% |
| Simulation | 5,000 paths; reproducible seed; no automatic historical calibration |

Change these assumptions in the notebook or `config/demo.json`. Local JSON use:

```bash
python -m wealthlab --config config/demo.json --root .
```

## Validation and limitations

Run `python -m unittest discover -s tests -v` and `python tools/check_notebook.py`.
The latter executes every plain-Python notebook code cell in a fresh temporary
directory. It is not a Jupyter-kernel or Colab-browser integration test.

Actual Yahoo/FRED network calls were not executed in the artifact-building
environment. Provider extraction, failure behavior, source separation, cache
checksums, and cached FRED lagging were tested offline. Provider availability and
the current Colab environment still require a live smoke test.

No taxes, suitability determination, lending, estate planning, whole-share lots,
broker execution, point-in-time security selection, or exchange-calendar
completeness guarantee is included. See the guide for the financial consequences
of these assumptions. Do not publish Yahoo-derived data without verifying rights.

## Resume description

Use after reproducing the work and being able to explain its assumptions:

> Built a Python/Google Colab wealth analytics platform combining multi-asset
> portfolio accounting, transaction-cost-aware rebalancing, reconciled dollar
> attribution, risk diagnostics, and Monte Carlo client spending analysis;
> produced reproducible HTML reports with documented data provenance and automated
> financial validation tests.

Describe the shipped example as synthetic. Do not claim live client use,
investment outperformance, regulatory compliance, or production deployment.

## Primary documentation

- [yfinance download parameters](https://ranaroussi.github.io/yfinance/reference/api/yfinance.download.html)
- [yfinance project and usage notice](https://github.com/ranaroussi/yfinance)
- [FRED observations API](https://fred.stlouisfed.org/docs/api/fred/series_observations.html)
- [FRED API keys](https://fred.stlouisfed.org/docs/api/api_key.html)
- [FRED/ALFRED real-time periods](https://fred.stlouisfed.org/docs/api/fred/realtime_period.html)
- [UBS investment philosophy](https://www.ubs.com/us/en/wealth-management/insights/article.3760299.html)
- [J.P. Morgan private-bank services](https://privatebank.jpmorgan.com/nam/en/services)

Code license: MIT; provider data remains subject to its own terms.
