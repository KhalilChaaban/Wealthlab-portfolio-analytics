# Validation record

The supplied artifact was checked on 2026-11-04 with Python 3.12.14, NumPy
2.3.5, pandas 2.2.3, SciPy 1.17.0, and matplotlib 3.10.8.

## Completed checks

- **38 offline tests passed.** Coverage includes hand-calculated buy-and-hold
  drift, month-boundary execution timing, the self-financing cost equation,
  initial purchase cost, weekend fee accrual, exact P&L reconciliation, and
  unchanged historical results when future observations are appended.
- Data-contract tests cover both Yahoo MultiIndex orientations, refusal to
  substitute unadjusted prices, explicit provider failure, source-separated
  caches, checksum corruption, duplicate conflicts, invalid prices, missing
  interior observations, late inception, and lagged cached FRED observations.
- Planning tests cover deterministic cash-flow solutions, annual growth and fee
  compounding, real-dollar deflation, one-off spending, absorbing depletion,
  legacy-target semantics, reproducible shocks, and spending sensitivity.
- An end-to-end test verifies the HTML report, five PNG figures, twelve CSVs
  including synthetic prices, JSON manifest, attribution reconciliation, and
  escaping of user-supplied report text.
- **All 23 notebook code cells executed successfully** in a fresh temporary
  workspace and separate Python process. The notebook produced its report and
  downloadable run ZIP. Optional widget rendering was disabled in this check.
- The default command-line demo completed. Five saved figure panels were
  visually inspected; title spacing and label density were corrected.

## What these checks do not establish

The notebook was computationally executed as ordinary Python, not in an actual
Google Colab browser or Jupyter kernel. Live Yahoo and FRED requests were not
executed in the artifact-building environment. Their schema and failure
contracts were tested offline; current provider access, credentials, licensing,
and optional widget behavior still need a user-side smoke test.

No live client, brokerage integration, suitability review, tax calculation,
regulatory validation, or external GitHub deployment occurred. GitHub Actions
configuration is included but has not run on a remote repository.

## Reproduce

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python tools/check_notebook.py
python -m wealthlab --source demo --root .
```

For a fixed core environment, use `requirements-tested.txt` on a compatible
Python interpreter. Test any dependency upgrades before relying on the results.
